package com.infinite.hibernate.dinterface;

import com.infinite.pojo.Product;

public interface IProduct {

public void createRecord(String product_name,int price,int quantity,int subtotal,Product pr);

public void updateRecord();

public void deleteRecords();

}



