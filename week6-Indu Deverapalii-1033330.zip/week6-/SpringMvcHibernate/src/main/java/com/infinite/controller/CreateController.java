package com.infinite.controller;
import com.infinite.hibernate.dImpl.CartImplementation;
import com.infinite.pojo.Product;

import org.apache.commons.logging.Log;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
public class CreateController {
	private static final Log logger= Logger.getLogger(CreateController.class);
	private ApplicationContext con;
	@RequestMapping(value="/insert",method=RequestMethod.POST)
	public String insert(@ModelAttribute("bean") Product e,Model m){
		con=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		CartImplementation obj=con.getBean("dao",CartImplementation.class);
		obj.createRecord("Bottle", 200, 10, 2000, e);
		String Product=e.getProduct();
		int Price=e.getPrice();
		int Quantity=e.getQuantity();
		int subtotal=e.getSubtotal();
		//Session sessionobj = sessionFactory;
		m.addAttribute("msg",Product); 
		logger.info("Create Controller");
		return "update";	
	}
}