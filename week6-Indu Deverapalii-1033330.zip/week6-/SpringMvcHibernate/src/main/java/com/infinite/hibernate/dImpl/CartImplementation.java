package com.infinite.hibernate.dImpl;
import javax.persistence.Query;
import javax.transaction.Transaction;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import com.infinite.helper.DAOhelper;
import com.infinite.hibernate.dinterface.IProduct;
import com.infinite.pojo.Product;

public class CartImplementation implements IProduct{
	static Session sessionObj;
	static SessionFactory sessionFactoryObj;
	private Configuration con;
	private Transaction t;
	public void saveData(Product e) {
		con = new Configuration().configure("hibernate.cfg.xml");
		sessionFactoryObj = con.buildSessionFactory();
		sessionObj = sessionFactoryObj.openSession();
		t = (Transaction) sessionObj.beginTransaction();
		sessionObj.save(e);
	}
	public void createRecord(String product_name, int price, int quantity, int subtotal,Product pr) {
		// TODO Auto-generated method stub
		try {
			sessionObj = DAOhelper.buildSessionFactory().openSession();
			// Getting Transaction Object From Session Object
			sessionObj.beginTransaction();
			Product c = (Product) sessionObj.get(Product.class,pr.getId());
			c.setProduct(c.getProduct());
			c.setPrice(c.getPrice());
			c.setQuantity(c.getQuantity());
			c.setSubtotal(c.getSubtotal());
			sessionObj.update(c);
			sessionObj.save(c);
			sessionObj.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				sessionObj.close();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}


	public void deleteRecords() {
		// TODO Auto-generated method stub

		sessionObj=DAOhelper.buildSessionFactory().openSession();
		sessionObj.beginTransaction();
		Query q= sessionObj.createQuery("delete from Student where student_id=2");
		q.executeUpdate();

	}
	public void updateRecord() {
		// TODO Auto-generated method stub
		
	}
	
	

}



