

create table cart( product_id int,product_name char(90),price int,quantity int,subtotal int);